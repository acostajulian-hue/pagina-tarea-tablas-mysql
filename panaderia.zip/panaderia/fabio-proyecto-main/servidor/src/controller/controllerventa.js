import { conectar } from "../database/conexion.js";
const bdd= await conectar();

// Carga clientes, productos y ventas para mostrar la pantalla de ventas
async function mostrar(resp, {mensaje=null, error=null, status=200}={}){
    try{
        const [clientes]= await bdd.query("SELECT idclientes,nombre,apellido FROM clientes ORDER BY apellido,nombre");
        const [productos]= await bdd.query("SELECT idproductos,nombre,precio,stock FROM productos ORDER BY nombre");
        const [ventas]= await bdd.query(
            `SELECT v.idventas, c.nombre AS cnombre, c.apellido, p.nombre AS pnombre, v.cantidad, v.total, v.fecha
             FROM ventas v
             JOIN clientes c ON c.idclientes = v.idclientes
             JOIN productos p ON p.idproductos = v.idproductos
             ORDER BY v.fecha DESC, v.idventas DESC
             LIMIT 50`);
        resp.status(status).render('ventas',{clientes,productos,ventas,mensaje,error});
    }catch(e){
        console.log(e);
        resp.status(500).send('Error al leer las ventas');
    }
}

// GET /ventas
export const vmenu = (peq,resp)=>{
    const mensaje = peq.query.ok ? 'Venta registrada correctamente' : null;
    mostrar(resp,{mensaje});
};

// POST /ventas/agregar
export const vagregar = async (peq,resp)=>{
    const idclientes = parseInt(peq.body.idclientes);
    const idproductos = parseInt(peq.body.idproductos);
    const cantidad = parseInt(peq.body.cantidad);

    if(!idclientes || !idproductos || !cantidad || cantidad < 1){
        return mostrar(resp,{error:'Elegí un cliente, un producto y una cantidad válida',status:400});
    }
    try{
        const [prod]= await bdd.query("SELECT precio FROM productos WHERE idproductos = ?",[idproductos]);
        if(prod.length===0){
            return mostrar(resp,{error:'El producto no existe',status:400});
        }
        // el total se calcula en el servidor: precio x cantidad
        const total = Math.round(Number(prod[0].precio) * cantidad * 100) / 100;
        await bdd.query(
            "INSERT INTO ventas (idclientes,idproductos,cantidad,total) VALUES (?,?,?,?)",
            [idclientes,idproductos,cantidad,total]);
        resp.redirect('/ventas?ok=1');
    }catch(error){
        console.log(error);
        const msg = error.code==='ER_NO_REFERENCED_ROW_2' ? 'El cliente o el producto no existe' : 'No se pudo registrar la venta';
        mostrar(resp,{error:msg,status:400});
    }
};