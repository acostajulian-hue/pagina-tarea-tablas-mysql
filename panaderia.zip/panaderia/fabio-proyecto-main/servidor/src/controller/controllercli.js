import { conectar } from "../database/conexion.js";
const bdd= await conectar();

export const cmenu = (peq, resp)=>{
    resp.render('clientes');
};

//  ALTA 
export const calta =(peq,resp)=>{
    resp.render('clialta',{error:null,datos:{}});
};

export const cguardar = async (peq,resp)=>{
    const {nombre,apellido,dni,telefono,email,direccion}=peq.body;
    try{
        const sql="INSERT INTO clientes (nombre,apellido,dni,telefono,email,direccion) VALUES (?,?,?,?,?,?)";
        await bdd.query(sql,[nombre,apellido,dni,telefono||null,email||null,direccion||null]);
        resp.redirect('/cliente/climostrar');
    }
    catch(error){
        console.log(error);
        const msg = error.code==='ER_DUP_ENTRY' ? 'Ya existe un cliente con ese DNI' : 'No se pudo guardar el cliente';
        resp.status(400).render('clialta',{error:msg,datos:peq.body});
    }
};

//  BAJA 
export const cbaja=(peq,resp)=>{
    resp.render('clibaja',{mensaje:null,error:null});
};

export const celiminar = async (peq,resp)=>{
    try{
        const [r]= await bdd.query("DELETE FROM clientes WHERE idclientes = ?",[peq.body.idclientes]);
        if(r.affectedRows===0){
            return resp.status(404).render('clibaja',{mensaje:null,error:'No existe un cliente con ese ID'});
        }
        resp.render('clibaja',{mensaje:'Cliente eliminado correctamente',error:null});
    }
    catch(error){
        console.log(error);
        resp.status(500).render('clibaja',{mensaje:null,error:'No se pudo eliminar el cliente'});
    }
};

//  MODIFICACION 
export const cmod= async (peq,resp)=>{
    // si viene ?idclientes= se precargan los datos actuales
    let datos={};
    let error=null;
    const id=peq.query.idclientes;
    if(id){
        try{
            const [rows]= await bdd.query("SELECT * FROM clientes WHERE idclientes = ?",[id]);
            if(rows.length) datos=rows[0]; else error='No existe un cliente con ese ID';
        }catch(e){ console.log(e); error='Error al buscar el cliente'; }
    }
    resp.render('climod',{mensaje:null,error,datos});
};

export const cactualizar = async (peq,resp)=>{
    const {idclientes,nombre,apellido,dni,telefono,email,direccion}=peq.body;
    try{
        const [r]= await bdd.query(
            "UPDATE clientes SET nombre=?,apellido=?,dni=?,telefono=?,email=?,direccion=? WHERE idclientes=?",
            [nombre,apellido,dni,telefono||null,email||null,direccion||null,idclientes]);
        if(r.affectedRows===0){
            return resp.status(404).render('climod',{mensaje:null,error:'No existe un cliente con ese ID',datos:peq.body});
        }
        resp.render('climod',{mensaje:'Cliente actualizado correctamente',error:null,datos:peq.body});
    }
    catch(error){
        console.log(error);
        const msg = error.code==='ER_DUP_ENTRY' ? 'Ya existe otro cliente con ese DNI' : 'No se pudo actualizar el cliente';
        resp.status(400).render('climod',{mensaje:null,error:msg,datos:peq.body});
    }
};

//  CONSULTA 
export const ccons= async (peq,resp)=>{
    const id=peq.query.idclientes;
    if(!id) return resp.render('clicons',{cliente:null,error:null});
    try{
        const [rows]= await bdd.query("SELECT * FROM clientes WHERE idclientes = ?",[id]);
        if(rows.length) resp.render('clicons',{cliente:rows[0],error:null});
        else resp.render('clicons',{cliente:null,error:'No existe un cliente con ese ID'});
    }catch(error){
        console.log(error);
        resp.status(500).render('clicons',{cliente:null,error:'Error al consultar'});
    }
};

//  LISTADO 
export const cmt= async (peq,resp)=>{
    try{
        const[registros]= await bdd.query("SELECT idclientes,nombre,apellido,dni,telefono,email,direccion from clientes order by idclientes");
        resp.render('climostrar',{registros});
    }
    catch(error){
        console.log(error);
        resp.status(500).send('Error al leer los clientes');
    }
};