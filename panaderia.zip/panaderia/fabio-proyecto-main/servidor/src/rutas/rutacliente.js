import { calta,cguardar,cbaja,celiminar,ccons,cmenu,cmod,cactualizar,cmt } from "../controller/controllercli.js";
import express from "express";

console.log('>>> RUTAS DE CLIENTES NUEVAS CARGADAS');

const Rclientes = express.Router();

Rclientes.get('/clientes',cmenu);
Rclientes.get('/cliente/clialta',calta)
Rclientes.post('/cliente/clialta',cguardar)
Rclientes.get('/cliente/clibaja',cbaja)
Rclientes.post('/cliente/clibaja',celiminar)
Rclientes.get('/cliente/climod',cmod)
Rclientes.post('/cliente/climod',cactualizar)
Rclientes.get('/cliente/clicons',ccons)
Rclientes.get('/cliente/climostrar',cmt)

export{Rclientes}