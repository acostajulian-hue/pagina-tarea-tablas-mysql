import express from "express";
import { vmenu,vagregar } from "../controller/controllerventa.js";

const Rventas = express.Router();

Rventas.get('/ventas', vmenu)
Rventas.post('/ventas/agregar', vagregar)

export{Rventas}